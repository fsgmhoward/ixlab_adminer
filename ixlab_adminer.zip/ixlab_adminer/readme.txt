﻿该版本主要更新了如下方面：
1.更新内核到4.2.3稳定版
2.重写adminauth.php，使用无名智者的MySQL/MySQLi库，去除多余代码
3.现在即使单独拿出整个程序（即不放在云签plugins文件夹内）也能用，与原版完全一样

该版本已经在Stusgame Tiebasigner V4.1 RC3测试，测试时间为2016年1月3日。
请注意：检测发现当使用PHP7时，会出现一个warning，这个是原本Adminer内核的问题，可通过修改报错等级去除。

若有问题欢迎反馈到fsgmhoward@foxmail.com。

本软件遵守Apache License 2.0/GPL 2协议